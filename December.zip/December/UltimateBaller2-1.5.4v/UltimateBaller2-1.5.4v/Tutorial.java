import greenfoot.*;
public class Tutorial extends World 
{
    private Man man = new Man();
    private Hoop hoop = new Hoop();
    double timeCreation = System.currentTimeMillis();
    private long startTime; 
    private int duration = 30; 
      //  private GreenfootSound gfs_MainMenu;
    public Tutorial() {    
        super(1000,667, 1); 
        
        //gfs_MainMenu = new GreenfootSound("TutorialBg.mp3");
        NextLevelZone backToMenuZone = new NextLevelZone(new MainMenu(), 50, 10);
        addObject(backToMenuZone, 900, 300); // Position it where the ball is expected to collide
        startTime = System.currentTimeMillis();
        prepare();
    }
    
    public void act()
    {
        text("Shoot as many hoops possible! You have " +man.getAttempts() + " attempts.",360,250/2,15,true);
        long elapsedTime = (System.currentTimeMillis() - startTime) / 1000; // Calculate elapsed time in seconds
        int remainingTime = duration - (int) elapsedTime; // Calculate remaining time
        
         if(Greenfoot.isKeyDown("space")){
            Greenfoot.setWorld(new MainMenu());
        }
        if (remainingTime > 0) {
            showText("Time: " + remainingTime, getWidth() / 2, 20); // Display remaining time
        } else {
            showText("Time's up!", getWidth() / 2, 20);
            Greenfoot.stop(); // Stop the simulation when time is up
        }
    }    
    //public void started() 
    //  {
    //    gfs_MainMenu.playLoop();
    // }
    
    // public void stopped() 
    // {
    //       gfs_MainMenu.stop();
    // }
    private void prepare()
    {

        addObject(man,39,319);

        addObject(hoop,935,365);
        BackboardZone backboardZone = new BackboardZone(40, 200);
        addObject(backboardZone,992,208);
    }

    public void text(String message, int x, int y, int FontSize, boolean attemptsMsg)
    {
        GreenfootImage bg = getBackground();
        Font font = new Font(FontSize);
        bg.setFont(font);
        bg.setColor(Color.WHITE); // Set to background color to clear the text area
        // Clear area slightly larger than text
        if(attemptsMsg){
           bg.fillRect(x - 10, y - FontSize, 370, FontSize + 10); 
        }
        // Draw the new text
        bg.setColor(Color.BLACK);
        bg.drawString(message, x, y);
    }
}