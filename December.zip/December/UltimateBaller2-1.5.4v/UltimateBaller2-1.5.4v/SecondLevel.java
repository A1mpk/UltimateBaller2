import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class SecondLevel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SecondLevel extends World
{
    private Man man = new Man();
    private Hoop hoop = new Hoop();
    private long startTime; 
    private int duration = 30; 
    /**
     * Constructor for objects of class SecondLevel.
     * 
     */
    public SecondLevel()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000,667, 1); 
        startTime = System.currentTimeMillis();
        NextLevelZone nextLevelZone = new NextLevelZone(new ThirdLevel(), 50, 10);
        addObject(nextLevelZone, 900, 300);// Position it near the net; adjust coordinates
        prepare();
        
    }
        public void act()
    {
        long elapsedTime = (System.currentTimeMillis() - startTime) / 1000; // Calculate elapsed time in seconds
        int remainingTime = duration - (int) elapsedTime; // Calculate remaining time

         if(Greenfoot.isKeyDown("space")){
            Greenfoot.setWorld(new MainMenu());
        }
        if (remainingTime > 0) {
            showText("Time: " + remainingTime, getWidth() / 2, 20); // Display remaining time
        } 
        
         if(man.getAttempts() == 0 || remainingTime < 0 ){
                Greenfoot.setWorld(new LostScreen());
            }
        text("Shoot as many hoops possible! You have " +man.getAttempts() + " attempts.",360,250/2,15,true);
    }   
    
    private void prepare()
    {
Wall wall2 = new Wall(75, 75,false);
        addObject(man,39,319);

        addObject(hoop,935,365);
        BackboardZone backboardZone = new BackboardZone(40, 200);
        addObject(backboardZone,992,208);

       
        addObject(wall2,512,526);
        wall2.setLocation(456,353);

    }

    public void text(String message, int x, int y, int FontSize, boolean attemptsMsg)
    {
        GreenfootImage bg = getBackground();
        Font font = new Font(FontSize);
        bg.setFont(font);
        bg.setColor(Color.WHITE); // Set to background color to clear the text area
        // Clear area slightly larger than text
        if(attemptsMsg){
           bg.fillRect(x - 10, y - FontSize, 370, FontSize + 10); 
        }
        // Draw the new text
        bg.setColor(Color.BLACK);
        bg.drawString(message, x, y);
    }
}
