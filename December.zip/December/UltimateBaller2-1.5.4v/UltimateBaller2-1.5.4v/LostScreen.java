import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LostScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LostScreen extends World
{
double timeBlackScreenCreation = System.currentTimeMillis();
    /**
     * Constructor for objects of class LostScreen.
     * 
     */
    public LostScreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000,667, 1); 
        Greenfoot.playSound("mutantdie.wav");
    }
    public void act(){
        if (System.currentTimeMillis() >= (timeBlackScreenCreation + (2 * 1000)))
      {
          Greenfoot.setWorld(new MainMenu());
      }
    }
}
