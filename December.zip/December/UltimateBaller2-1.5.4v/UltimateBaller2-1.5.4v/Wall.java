import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Wall here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Wall extends Bouncer
{
       private int direction = 1; // 1 for moving up, -1 for moving down
    private int speed = 2; // Speed of the movement
    private int hoopX = 900; // X-coordinate of the hoop (update with actual value)
    private int hoopY = 200; // Y-coordinate of the hoop (update with actual value)
    private int range = 100;
    private boolean movement = true;
    
    /**
     * Act - do whatever the Wall wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Wall(int width, int height, boolean movement) {
        super(width, height);
        this.movement = movement;
        img.setColor(Color.BLACK); // Set color to black for the border
        img.drawRect(0, 0, width - 1, height - 1); // Draw the black border
        img.setColor(Color.RED); // Set color to white for the inner fill
        img.fillRect(1, 1, width - 2, height - 2); // Fill the inner area with white
        setImage(img);
    }

    public void act() {
        // Check for collisions with the basketball
        
        Actor ball = getOneIntersectingObject(BasketBall.class);
        if (ball != null) {
            bounceBall((BasketBall) ball);
        }
        if(movement){
             int currentY = getY();
        if (currentY <= hoopY - range) {
            direction = 1; // Move down if at the top limit
        } else if (currentY >= hoopY + range) {
            direction = -1; // Move up if at the bottom limit
        }

        // Move the blocker up or down
        setLocation(getX(), getY() + (direction * speed));
        
        // Randomly change direction with a certain probability
        if (Greenfoot.getRandomNumber(100) < 2) { // Adjust the probability as needed
            direction *= -1; // Reverse the direction
        }
        
        }
   
    }

    private void bounceBall(BasketBall ball) {
        // Get the ball's current velocity
        Vector velocity = ball.getVelocity();

        // Determine if collision is horizontal or vertical
        int ballX = ball.getX();
        int ballY = ball.getY();
        int zoneX = getX();
        int zoneY = getY();

        // Adjust based on relative position
        if (Math.abs(ballX - zoneX) > Math.abs(ballY - zoneY)) {
            // Horizontal bounce
            velocity.setX(-velocity.getX());
        } else {
            // Vertical bounce
            velocity.setY(-velocity.getY());
        }

        // Update the ball's velocity
        ball.setVelocity(velocity);
    }
}
