import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class RimTipZone here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class RimTipZone extends Bouncer
{
    public RimTipZone(int width, int height) {
        super(width, height);
        img.setColor(Color.GREEN);
        img.fillRect(0,0,width,height);
        img.setTransparency(0);
        setImage(img);
    }

    public void act() {
        Actor ball = getOneIntersectingObject(BasketBall.class); // Replace Ball with the name of your ball class
        if (ball != null) {
            bounceBall((BasketBall) ball);
        }
    }

   private void bounceBall(BasketBall ball) {
        // Get the ball's current velocity
        Vector velocity = ball.getVelocity();

        // Reflect the horizontal component of the velocity
        velocity.setX(-velocity.getX());

        // Update the ball's velocity
        ball.setVelocity(velocity);
    }
}