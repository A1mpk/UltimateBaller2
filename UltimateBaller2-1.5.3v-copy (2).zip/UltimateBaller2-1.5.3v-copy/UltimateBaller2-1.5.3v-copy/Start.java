import greenfoot.*;
public class Start extends Actor
{
    public void act()
    {
        if (Greenfoot.mouseMoved(this))
        {
            setImage("Start_Highlighted.png");
        }

        if (Greenfoot.mouseMoved(getWorld()))
        {
            setImage("Start.png");
        }

        if (Greenfoot.mouseClicked(this)) 
        {
            getWorld().stopped();
            FirstLevel level1 = new FirstLevel();
            Greenfoot.setWorld(level1);
        }
    }
}
