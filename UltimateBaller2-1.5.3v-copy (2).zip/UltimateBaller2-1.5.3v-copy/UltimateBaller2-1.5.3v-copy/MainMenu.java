import greenfoot.*;
public class MainMenu extends World
{
    private GreenfootSound gfs_MainMenu;
    /**
     * Constructor for objects of class MainMenu.
     * 
     */
    public MainMenu()
    {    
        super(726,613, 1); 
        prepare();
        gfs_MainMenu = new GreenfootSound("coolahhbeat.mp3");
    }
    
    public void started() 
    {
        gfs_MainMenu.playLoop();
    }
    
    public void stopped() 
    {
         gfs_MainMenu.stop();
    }
    
    private void prepare()
    {
        Start start = new Start();
        addObject(start,276,228);
        Extra extra = new Extra();
        addObject(extra,278,406);
        removeObject(start);
        removeObject(extra);
        addObject(start,367,261);
        addObject(extra,368,467);
        extra.setLocation(348,483);
        removeObject(extra);
        removeObject(start);
        addObject(start,141,426);
        addObject(extra,142,522);
    }
}
