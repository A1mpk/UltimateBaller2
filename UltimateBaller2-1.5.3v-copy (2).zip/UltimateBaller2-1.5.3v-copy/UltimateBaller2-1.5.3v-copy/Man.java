import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Man here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Man extends Actor
{
    private final static double BASKET_BALL_V = 1200.0;
    public void act()
    {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        
        if(mouse != null)
        {
            Vector ballToMouse = new Vector(mouse.getX() - getX(), mouse.getY() - getY());
            
            lineVector(ballToMouse);
            if(Greenfoot.mouseClicked(null))
            {
                ballToMouse.normalize();
                ballToMouse = Vector.multiply(ballToMouse, BASKET_BALL_V);
                
                BasketBall ball = new BasketBall();
                ball.setVelocity(ballToMouse);
                getWorld().addObject(ball, getX(), getY());
            }
        }
    }
    public void lineVector(Vector v) {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        
        if(mouse != null)
        {
            Vector ballToMouse = new Vector(mouse.getX() - getX(), mouse.getY() - getY());
            
            double adjacent = ballToMouse.getX();
            double opposite = ballToMouse.getY();
            
            double angleRadians = Math.atan2(opposite, adjacent);
            double angleDegrees = Math.toDegrees(angleRadians);
            
            setRotation((int) angleDegrees);
        }
    }
}
