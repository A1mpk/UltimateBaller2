import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot, and MouseInfo)

public class BackboardZone extends Bouncer {
    public BackboardZone(int width, int height) {
       super(width, height);
        img.setColor(Color.BLACK); // Set color to black for the border
        img.drawRect(0, 0, width - 1, height - 1); // Draw the black border
        img.setColor(Color.WHITE); // Set color to white for the inner fill
        img.fillRect(1, 1, width - 2, height - 2); // Fill the inner area with white
        setImage(img);
    }

    public void act() {
        // Check for collisions with the basketball
        Actor ball = getOneIntersectingObject(BasketBall.class);
        if (ball != null) {
            bounceBall((BasketBall) ball);
        }
    }

    private void bounceBall(BasketBall ball) {
        // Get the ball's current velocity
        Vector velocity = ball.getVelocity();

        // Determine if collision is horizontal or vertical
        int ballX = ball.getX();
        int ballY = ball.getY();
        int zoneX = getX();
        int zoneY = getY();

        // Adjust based on relative position
        if (Math.abs(ballX - zoneX) > Math.abs(ballY - zoneY)) {
            // Horizontal bounce
            velocity.setX(-velocity.getX());
        } else {
            // Vertical bounce
            velocity.setY(-velocity.getY());
        }

        // Update the ball's velocity
        ball.setVelocity(velocity);
    }
}