import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot, and MouseInfo)

public class BackboardZone extends Actor {
    public BackboardZone() {
        GreenfootImage image = new GreenfootImage(50, 200); // Adjust size to match the backboard
        image.setTransparency(0); // Make the object invisible
        setImage(image);
    }

    public void act() {
        Actor ball = getOneIntersectingObject(BasketBall.class); // Replace Ball with the name of your ball class
        if (ball != null) {
            bounceBall((BasketBall) ball);
        }
    }

    private void bounceBall(BasketBall ball) {
        // Get the ball's current velocity
        Vector velocity = ball.getVelocity();

        // Reflect the horizontal component of the velocity
        velocity.setX(-velocity.getX());

        // Update the ball's velocity
        ball.setVelocity(velocity);
    }
}