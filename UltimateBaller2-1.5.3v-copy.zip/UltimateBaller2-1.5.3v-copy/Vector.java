public class Vector {
    private double x;
    private double y;

    // Constructor to create a vector with initial x and y components
    public Vector(double x, double y) {
        this.x = x;
        this.y = y;
    }

    // Getter for x component
    public double getX() {
        return x;
    }

    // Getter for y component
    public double getY() {
        return y;
    }

    // Setter for x component
    public void setX(double x) {
        this.x = x;
    }

    // Setter for y component
    public void setY(double y) {
        this.y = y;
    }

    // Negates the vector (inverts both x and y components)
    public void negate() {
        x = -x;
        y = -y;
    }

    // Calculates the magnitude (length) of the vector
    public double magnitude() {
        return Math.sqrt(x * x + y * y);
    }

    // Normalizes the vector (scales it to have a magnitude of 1)
    public void normalize() {
        double m = magnitude();
        if (m != 0) { // Avoid division by zero
            x /= m;
            y /= m;
        }
    }

    // Adds two vectors and returns the result as a new vector
    public static Vector add(Vector v1, Vector v2) {
        return new Vector(v1.x + v2.x, v1.y + v2.y);
    }

    // Multiplies the vector by a scalar value and returns the result
    public static Vector multiply(Vector v, double value) {
        return new Vector(v.x * value, v.y * value);
    }

    // Calculates the dot product of two vectors
    public static double dot(Vector v1, Vector v2) {
        return v1.x * v2.x + v1.y * v2.y;
    }
}