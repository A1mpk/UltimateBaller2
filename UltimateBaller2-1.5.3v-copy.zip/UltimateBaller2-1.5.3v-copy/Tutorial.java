import greenfoot.*;
public class Tutorial extends World 
{
    private Man man = new Man();
    private Hoop hoop = new Hoop();
    double timeCreation = System.currentTimeMillis();
  //  private GreenfootSound gfs_MainMenu;
    public Tutorial() {    
        super(1000,667, 1); 
        
        

        text("Tutorial",360,70,70,false);
        //gfs_MainMenu = new GreenfootSound("TutorialBg.mp3");
        prepare();
    }
    
    public void act()
    {
        text("Shoot as many hoops possible! You have " +man.getAttempts() + " attempts.",360,70,15,true);
        
          
      
}
    
//public void started() 
  //  {
    //    gfs_MainMenu.playLoop();
   // }
    
   // public void stopped() 
   // {
  //       gfs_MainMenu.stop();
  // }
    private void prepare()
    {

        addObject(man,39,319);

        addObject(hoop,933,343);
    }
    
    public void text(String message, int x, int y, int FontSize, boolean attemptsMsg)
    {
        GreenfootImage bg = getBackground();
        Font font = new Font(FontSize);
        bg.setFont(font);
       bg.setColor(Color.WHITE); // Set to background color to clear the text area
 // Clear area slightly larger than text
if(attemptsMsg){
       bg.fillRect(x - 10, y - FontSize, 370, FontSize + 10); 
}
    // Draw the new text
    bg.setColor(Color.BLACK);
    bg.drawString(message, x, y);
        
    }
}