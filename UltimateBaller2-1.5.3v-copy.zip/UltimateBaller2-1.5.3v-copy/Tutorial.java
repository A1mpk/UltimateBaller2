import greenfoot.*;
public class Tutorial extends World 
{
    public Tutorial() {    
        super(880, 650, 1); 
        prepare();
        text("Welcome to training! Use the mouse to aim in any direction. Press the left mouse button to throw your ball!",10,200);
    }
    
    public void act()
    {
        prepare();
    }
    
    private void prepare()
    {
        Man man = new Man();
        addObject(man,39,319);
    }
    
    public void text(String message, int x, int y)
    {
        GreenfootImage bg = getBackground();
        Font font = new Font(18);
        bg.setFont(font);
        bg.setColor(Color.BLACK);
        bg.drawString(message, x, y);
    }
}