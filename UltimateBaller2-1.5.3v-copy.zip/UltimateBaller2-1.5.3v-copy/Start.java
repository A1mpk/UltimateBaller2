import greenfoot.*;
public class Start extends Actor
{
    public void act()
    {
        if (Greenfoot.mouseMoved(this))
        {
            setImage("Start_Highlighted.png");
        }

        if (Greenfoot.mouseMoved(getWorld()))
        {
            setImage("Start.png");
        }

        if (Greenfoot.mouseClicked(this)) 
        {
            getWorld().stopped();
            Tutorial tutorial = new Tutorial();
            Greenfoot.setWorld(tutorial);
        }
    }
}
