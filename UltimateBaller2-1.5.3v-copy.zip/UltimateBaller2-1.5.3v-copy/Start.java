import greenfoot.*;
public class Start extends Actor
{
    
    public void act()
    {
        if (Greenfoot.mouseMoved(this))
        {
            setImage("StartButtonYellow.png");
            
            
        }

        
        if (Greenfoot.mouseMoved(getWorld()))
        {
            setImage("StartButton.png");
        }

        if (Greenfoot.mouseClicked(this)) 
        {
            
            
            Greenfoot.playSound("ClickPressed2.wav");
            FirstLevel level1 = new FirstLevel();
            Greenfoot.setWorld(level1);
            
        }
    }
}
