import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class BasketBall extends Actor {
    private Vector position;           // Tracks the ball's position
    private Vector velocity;           // Ball's velocity
    private Vector acceleration;       // Acceleration (e.g., gravity)
    private long lastFrameTimeMS;      // Time of the last frame in milliseconds
    private double timeStepDuration;   // Time step for simulation
    private static final double GRAVITY = 9.8 * 200; // Gravity in pixels/sec² (200 pixels = 1 meter)

    public BasketBall() {
        // Initialize physics properties
        position = null; // Will be set in updatePhysics()
        velocity = new Vector(0.0, 0.0);
        acceleration = new Vector(0.0, GRAVITY);
        lastFrameTimeMS = System.currentTimeMillis();
        timeStepDuration = 1.0 / 60;
    }

    public void act() {
        updatePhysics();  // Simulate physics
        handleCollisions(); // Handle interactions with the backboard or rim
        ballLife();       // Remove the ball if it exits the world
        updateTimeStep(); // Update the time step for accurate physics
    }

    // Set the velocity
    public void setVelocity(Vector newVelocity) {
        velocity = newVelocity;
    }

    // Update physics simulation
    private void updatePhysics() {
        if (position == null) {
            position = new Vector(getX(), getY());
        }

        // Time step duration
        double dt = getTimeStepDuration();

        // Update velocity with acceleration
        Vector velocityChange = Vector.multiply(acceleration, dt);
        velocity = Vector.add(velocity, velocityChange);

        // Update position with velocity
        Vector positionChange = Vector.multiply(velocity, dt);
        position = Vector.add(position, positionChange);

        // Apply the new position to the actor
        setLocation((int) position.getX(), (int) position.getY());
    }

    // Handle collisions with backboard or rim
    private void handleCollisions() {
        // Check for collision with BackboardZone or RimTipZone
        Actor zone = getOneIntersectingObject(BackboardZone.class);
        if (zone == null) {
            zone = getOneIntersectingObject(RimTipZone.class);
        }

        if (zone instanceof BackboardZone) {
            // Bounce horizontally for backboard
            velocity.setX(-velocity.getX());
        } else if (zone instanceof RimTipZone) {
            // Bounce both horizontally and vertically for rim tips
            velocity.setX(-velocity.getX());
            velocity.setY(-velocity.getY());
        }
    }

    // Remove the ball if it goes out of the world
    private void ballLife() {
        if (atWorldEdge()) {
            getWorld().removeObject(this);
        }
    }

    // Check if the ball is at the world's edge
    private boolean atWorldEdge() {
        return getX() < 20 || getX() > getWorld().getWidth() - 20 || getY() < 20 || getY() > getWorld().getHeight() - 20;
    }

    // Update the time step for physics simulation
    private void updateTimeStep() {
        long currentTime = System.currentTimeMillis();
        timeStepDuration = (currentTime - lastFrameTimeMS) / 1000.0;
        lastFrameTimeMS = currentTime;
    }

    // Get the duration of the time step
    public double getTimeStepDuration() {
        return timeStepDuration;
    }
    
    public Vector getVelocity() {
    return velocity;
    }
}
