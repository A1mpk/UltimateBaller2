import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot, and MouseInfo)

public class RimTipZone extends Actor {
    public RimTipZone() {
        GreenfootImage image = new GreenfootImage(10, 10); // Adjust size to match the rim tip
        image.setTransparency(0); // Make the object invisible
        setImage(image);
    }

    public void act() {
        Actor ball = getOneIntersectingObject(BasketBall.class); // Replace Ball with the name of your ball class
        if (ball != null) {
            bounceBall((BasketBall) ball);
        }
    }

   private void bounceBall(BasketBall ball) {
        // Get the ball's current velocity
        Vector velocity = ball.getVelocity();

        // Reflect the horizontal component of the velocity
        velocity.setX(-velocity.getX());

        // Update the ball's velocity
        ball.setVelocity(velocity);
    }
}