import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Tutorial extends World 
{
    public Tutorial() {    
        super(600, 400, 1); 
        prepare();
    }
    
    private void prepare()
    {
        Man man = new Man();
        addObject(man,39,319);
    }
}