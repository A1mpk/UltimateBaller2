import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MainMenu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MainMenu extends World
{

    /**
     * Constructor for objects of class MainMenu.
     * 
     */
    public MainMenu()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Start start = new Start();
        addObject(start,276,228);
        Extra extra = new Extra();
        addObject(extra,278,406);
        Planet planet = new Planet();
        addObject(planet,538,536);

        removeObject(extra);
        removeObject(planet);

        removeObject(start);
        Extra extra2 = new Extra();
        addObject(extra2,486,367);
        addObject(start,301,282);
        Start start2 = new Start();
        addObject(start2,162,128);
        Start start3 = new Start();
        addObject(start3,436,126);
        Start start4 = new Start();
        addObject(start4,113,362);
    }
}
