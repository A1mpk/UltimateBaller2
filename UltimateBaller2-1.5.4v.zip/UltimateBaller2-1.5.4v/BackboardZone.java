import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot, and MouseInfo)

public class BackboardZone extends Bouncer {
    public BackboardZone(int width, int height) {
        super(width, height);
        img.fillRect(0,0,width,height);
        img.setTransparency(0);
        setImage(img);
    }

    public void act() {
        Actor ball = getOneIntersectingObject(BasketBall.class); // Replace Ball with the name of your ball class
        if (ball != null) {
            bounceBall((BasketBall) ball);
        }
    }

    private void bounceBall(BasketBall ball) {
        // Get the ball's current velocity
        Vector velocity = ball.getVelocity();

        // Reflect the horizontal component of the velocity
        velocity.setX(-velocity.getX());

        // Update the ball's velocity
        ball.setVelocity(velocity);
    }
}