import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Bouncer extends Actor
{
    GreenfootImage img;
    public Bouncer(int width, int height)
    {
        img = new GreenfootImage(width, height);
    }
}
