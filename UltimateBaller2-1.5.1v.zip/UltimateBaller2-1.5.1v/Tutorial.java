import greenfoot.*;
public class Tutorial extends World 
{
    public Tutorial() {    
        super(600, 400, 1); 
        prepare();
    }
    
    public void act()
    {
        prepare();
    }
    
    private void prepare()
    {
        Man man = new Man();
        addObject(man,39,319);
    }
}