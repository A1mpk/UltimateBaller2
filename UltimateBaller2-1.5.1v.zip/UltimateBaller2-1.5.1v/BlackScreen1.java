import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BlackScreen1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BlackScreen1 extends World
{
    double timeBlackScreenCreation = System.currentTimeMillis();
    /**
     * Constructor for objects of class BlackScreen1.
     * 
     */
    public BlackScreen1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 600, 1); 
    }
    
    public void act()
    {
      if (System.currentTimeMillis() >= (timeBlackScreenCreation + (1 * 1000)))
      {
          Greenfoot.setWorld(new SplashScreen());
      }
    }
    }

