import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot, and MouseInfo)

public class NextLevelZone extends Actor {
    private World nextLevel;

    public NextLevelZone(World nextLevel, int width, int height) {
        this.nextLevel = nextLevel;  // Store the next level that this zone should lead to
        
        GreenfootImage img = new GreenfootImage(width, height);
        img.setColor(Color.GREEN); // Visible for debugging; make transparent if not needed
        img.fillRect(0, 0, width, height);
        setImage(img);
    }

    public void act() {
        // Check for collision with the basketball
        Actor ball = getOneIntersectingObject(BasketBall.class);
        if (ball != null) {
            goToNextLevel();
        }
    }

    private void goToNextLevel() {
        Greenfoot.setWorld(nextLevel);  // Transition to the next level
    }
}