import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Man here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
    public class Man extends Actor{
    private final static double BASKET_BALL_V = 1400.0;
    private int attempts = 10;
    private final int cooldownMillis = 4000;

    public void act()
    {
        MouseInfo mouse = Greenfoot.getMouseInfo();
      long currentTime = System.currentTimeMillis();
      BasketBall ball = new BasketBall();
      
        if(attempts == 0){
            getWorld().removeObject(ball);
        }else{
            
            if(mouse != null)
        {
            Vector ballToMouse = new Vector(mouse.getX() - getX(), mouse.getY() - getY());
            lineVector(ballToMouse);
            if(Greenfoot.mouseClicked(null))
            {
                attempts--;
                ballToMouse.normalize();
                ballToMouse = Vector.multiply(ballToMouse, BASKET_BALL_V);
                
                Greenfoot.playSound("sfx_throw.wav");
                ball.setVelocity(ballToMouse);
                getWorld().addObject(ball, getX(), getY());
                 
            }
            
        }
        }
        
      
      
    }
    public void lineVector(Vector v) {
        MouseInfo mouse = Greenfoot.getMouseInfo();
        
        if(mouse != null)
        {
            Vector ballToMouse = new Vector(mouse.getX() - getX(), mouse.getY() - getY());
            
            double adjacent = ballToMouse.getX();
            double opposite = ballToMouse.getY();
            
            double angleRadians = Math.atan2(opposite, adjacent);
            double angleDegrees = Math.toDegrees(angleRadians);
            
            setRotation((int) angleDegrees);
        }
    }
    
    public int getAttempts(){
    return attempts;
    }
}
