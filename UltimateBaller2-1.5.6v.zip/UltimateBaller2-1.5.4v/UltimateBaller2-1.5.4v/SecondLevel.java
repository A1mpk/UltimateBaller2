import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class SecondLevel here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SecondLevel extends World
{
    private Man man = new Man();
    private Hoop hoop = new Hoop();
    /**
     * Constructor for objects of class SecondLevel.
     * 
     */
    public SecondLevel()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000,667, 1); 
        
        NextLevelZone nextLevelZone = new NextLevelZone(new ThirdLevel(), 50, 10);
        addObject(nextLevelZone, 900, 300);// Position it near the net; adjust coordinates
        prepare();
    }
    
    private void prepare()
    {

        addObject(man,39,319);

        addObject(hoop,935,365);
        BackboardZone backboardZone = new BackboardZone(40, 200);
        addObject(backboardZone,992,208);
        Wall wall = new Wall(50, 250);
        addObject(wall,460,99);
        wall.setLocation(492,125);
        Wall wall2 = new Wall(50, 250);
        addObject(wall2,512,526);
        wall2.setLocation(496,534);
    }
}
