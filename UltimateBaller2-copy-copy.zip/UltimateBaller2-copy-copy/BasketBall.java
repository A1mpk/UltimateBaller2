import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class BasketBall extends Actor
{
    private Point position;
    private Vector velocity;
    private Vector acceleration;
    
    private static final double GRAVITY = 9.8 * 200; // 200 pixels is 1 meter
    
    public BasketBall()
    {
        position = null;
        velocity = new Vector(0.0, 0.0);
        acceleration = new Vector(0.0, GRAVITY);
    }
    
    public void act() 
    {
        updatePhysics();
    }    
    
    public void setVelocity(Vector newValue)
    {
        velocity = newValue;
    }
    
    public void updatePhysics()
    {
        // Initial position
        if (position == null)
        {
            position = new Point(getX(), getY());
        }
        
        // Get time step duration
        Tutorial tutorial = (Tutorial) getWorld();
        double dt = tutorial.getTimeStepDuration();
        
        // Update velocity
        Vector velocityVariation = Vector.multiply(acceleration, dt);
        velocity = Vector.add(velocity, velocityVariation);

        // Update position
        Vector positionVariation = Vector.multiply(velocity, dt);
        position.add(positionVariation);
        
        // Set new actor position
        setLocation((int) position.getX(), (int) position.getY());        
    }
}
