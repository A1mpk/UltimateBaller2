import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Tutorial extends World 
{
    private long lastFrameTimeMS;
    private double timeStepDuration;
    public Tutorial() {    
        super(600, 400, 1); // Set the world size here
        // Add initial game setup, like adding the Man actor
        lastFrameTimeMS = System.currentTimeMillis();
        timeStepDuration = 1.0 / 60;
        prepare();
    }

    public void started()
    {
        lastFrameTimeMS = System.currentTimeMillis();
    }
    
    public void act() {
        timeStepDuration = (System.currentTimeMillis() - lastFrameTimeMS) /1000.0;
        lastFrameTimeMS = System.currentTimeMillis();
    }
    
    public double getTimeStepDuration()
    {
        return timeStepDuration;
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Man man = new Man();
        addObject(man,39,319);
    }
}