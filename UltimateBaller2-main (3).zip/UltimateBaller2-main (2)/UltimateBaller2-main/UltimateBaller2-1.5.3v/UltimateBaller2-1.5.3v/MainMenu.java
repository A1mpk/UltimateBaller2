import greenfoot.*;
public class MainMenu extends World
{
    private GreenfootSound gfs_MainMenu;
    /**
     * Constructor for objects of class MainMenu.
     * 
     */
    public MainMenu()
    {    
        super(726,613, 1); 
        prepare();
        gfs_MainMenu = new GreenfootSound("menu.mp3");
    }
    
    public void started() 
    {
        gfs_MainMenu.playLoop();
    }
    
    public void stopped() 
    {
         gfs_MainMenu.stop();
    }
    
    private void prepare()
    {
        Start start = new Start();
        addObject(start,276,228);
        Extra extra = new Extra();
        addObject(extra,278,406);
        removeObject(start);
        removeObject(extra);
        addObject(start,367,261);
        addObject(extra,368,467);
        extra.setLocation(348,483);
        removeObject(extra);
        removeObject(start);
        addObject(start,141,426);
        addObject(extra,142,522);
        Credits credits = new Credits();
        addObject(credits,140,467);
        extra.setLocation(116,499);
        extra.setLocation(116,510);
        extra.setLocation(116,510);
        extra.setLocation(116,510);
        removeObject(extra);
        removeObject(credits);
        removeObject(start);

        addObject(start,157,434);

        addObject(credits,155,499);

        addObject(extra,159,571);
    }
}
