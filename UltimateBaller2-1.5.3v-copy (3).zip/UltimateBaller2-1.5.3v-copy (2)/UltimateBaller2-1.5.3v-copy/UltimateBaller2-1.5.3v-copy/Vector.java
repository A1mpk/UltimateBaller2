
public class Vector  
{
    private double x;
    private double y;

    public Vector(double x, double y)
    {
        this.x = x;
        this.y = y;
    }
    
    public double getX()
    {
        return x;
    }
    
    public double getY()
    {
        return y;
    }

    public void negate()
    {
        x = -x;
        y = -y;
    }

    public double magnitude()
    {
        return Math.sqrt(dot(this, this));
    }

    public void normalize()
    {
        double m = magnitude();
        x /= m;
        y /= m;
    }
       
    public static Vector add(Vector v1, Vector v2)
    {
        return new Vector(v1.x + v2.x, v1.y + v2.y);
    }
    
    public static Vector multiply(Vector v, double value)
    {
        return new Vector(v.x*value, v.y*value);
    }
    
    public static double dot(Vector v1, Vector v2)
    {
        return v1.x * v1.x + v2.y * v2.y;
    }
}
