  import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class BasketBall extends Actor
{
    private Point position;
    private Vector velocity;
    private Vector acceleration;
    private long lastFrameTimeMS;
    private double timeStepDuration;
    int size = 50;
    private static final double GRAVITY = 9.8 * 200; // 200 pixels is 1 meter
    
    public BasketBall()
    {
        position = null;
        velocity = new Vector(0.0, 0.0);
        acceleration = new Vector(0.0, GRAVITY);
        lastFrameTimeMS = System.currentTimeMillis();
        timeStepDuration = 1.0 / 60;
    }
    
    public void act() 
    {
        updatePhysics();
        ballLife();
        timeSec();
     
    }    
    
    public void setVelocity(Vector newValue)
    {
        velocity = newValue;
    }
public void updatePhysics()
    {
        // Initial position
        if (position == null)
        {
            position = new Point(getX(), getY());
        }
        
        // Get time step duration
        double dt = getTimeStepDuration();
        
        // Update velocity
        Vector velocityVariation = Vector.multiply(acceleration, dt);
        velocity = Vector.add(velocity, velocityVariation);

        // Update position
        Vector positionVariation = Vector.multiply(velocity, dt);
        position.add(positionVariation);
        
        // Set new actor position
        setLocation((int) position.getX(), (int) position.getY());        
    }
    
    
    public boolean atWorldEdge()
    {
        if(getX() < 20 || getX() > getWorld().getWidth() - 20)
            return true;
        if(getY() < 20 || getY() > getWorld().getHeight() - 20)
            return true;
        else
            return false;
        
    }
    
     public void ballLife()
    {
        if(atWorldEdge())
            getWorld().removeObject(this);
    }
    
    public void started()
    {
        lastFrameTimeMS = System.currentTimeMillis();
    }
    
    public double getTimeStepDuration()
    {
        return timeStepDuration;
    }
    
    public void timeSec()
    {
        timeStepDuration = (System.currentTimeMillis() - lastFrameTimeMS) /1000.0;
        lastFrameTimeMS = System.currentTimeMillis();
    }
}
